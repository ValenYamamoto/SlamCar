import time 

import numpy as np
import pandas as pd 
import plotly.express as px 
import streamlit as st 

st.set_page_config(
    page_title="SLAM Dashboard",
    page_icon="✅",
    layout="wide",
)

st.title("SLAM Dashboard")


# creating a single-element container
placeholder = st.empty()


# near real-time / live feed simulation
for seconds in range(200):

    x = np.random.rand(10)
    y = np.random.rand(10)
    w = np.abs(np.random.rand(10))
    mc_x = np.mean(x)
    mc_y = np.mean(y)

    iw_x = np.sum(x*w)
    iw_y = np.sum(y*w)

    df = pd.DataFrame({'x': x, "y": y, "w": w})

    with placeholder.container():

        # create three columns
        kpi1, kpi2 = st.columns(2)

        # fill in those three columns with respective metrics or KPIs
        kpi1.metric(
            label="Monte Carlo Estimate",
            value=f"({mc_x:.2f}, {mc_y:.2f})",
        )
        
        kpi2.metric(
            label="Importance Weight Estimate",
            value=f"({iw_x:.2f}, {iw_y:.2f})",
        )
        
        fig = px.scatter(x=x, y=y)
        fig.update_xaxes(range=[-2, 2])
        fig.update_yaxes(range=[-2, 2])
        st.write(fig)
            
        st.markdown("### Detailed Data View")
        st.dataframe(df)
        time.sleep(1)
