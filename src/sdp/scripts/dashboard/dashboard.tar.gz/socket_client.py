# Client
import socket
import numpy as np
import time
import struct

HOST = '127.0.0.1'# localhost
PORT = 65432 # random number

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((HOST, PORT))
    print("CONNECTED")
    while True:
        c=''
        for i in range(10):
            a = np.random.uniform(0, 100)
            b = np.random.uniform(0, 100)
            c += f"{a:05.3f} {b:05.3f}\n\r"
        input("Press to continue")
        s.sendall(struct.pack("i", len(c)))
        s.sendall(bytes(c, 'utf-8'))
        print("SENDING", c, len(c))
        if s == "END":
            break
        time.sleep(0.5)


class Socket:


    def __init__(self, client, host: str, port: int):
        """
        host: address of server
        port: port on server to connect to
        """
        self._client = client
        self._socket = socket.socket()
        print(f"Connecting to {host} and port {port} ...")
        self._socket.connect((host, port))


    def close(self):
        """Close socket."""
        self._socket.close()
        print("Connection closed")


    def write(self, s: str):
        """Write to server."""
        if DEBUG:
            print("SEND:", repr(s))
        self._socket.sendall(struct.pack("i", len(s)))
        self._socket.sendall(bytes(s, 'utf-8'))


    def read(self, size):
        """Read from server."""
        line = self._instream.readline()
        if DEBUG:
            print("RECV:", repr(line))
        return line[:-1]

    def __call__(self, arg):
        if self._client:
            self.write(arg)
        else:
            return self.read(arg)

